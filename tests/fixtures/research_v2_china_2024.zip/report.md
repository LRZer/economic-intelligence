# 观澜研究快照：中国（CHN） · 2024 年

- 文档性质：基于固定数据快照的描述性宏观研究，不是实时交易信号。
- 报告编号：`5b71813574bfbd4f`；格式版本：2。
- 本国该年有效 WDI 指标：13/14。缺失值未填补。
- 数据快照下载时间（UTC）：2026-09-26T20:46:52.866725+00:00
- WDI 来源更新日期：2026-07-13
- 缺失值：保留为空；WDI 数值对应所标年份的当前发布版本，可能包含估计和后续修订，不跨年填补。

## 年度宏观指标

| 指标 | 数值 | 单位 | 来源 |
| --- | ---: | --- | --- |
| 国内生产总值 | 18.7万亿 | 现价美元 | [WDI NY.GDP.MKTP.CD](https://data.worldbank.org/indicator/NY.GDP.MKTP.CD) |
| GDP 实际增长率 | 5.0% | % | [WDI NY.GDP.MKTP.KD.ZG](https://data.worldbank.org/indicator/NY.GDP.MKTP.KD.ZG) |
| 人均 GDP | 13,293 美元 | 现价美元 | [WDI NY.GDP.PCAP.CD](https://data.worldbank.org/indicator/NY.GDP.PCAP.CD) |
| 消费者价格涨幅 | 0.2% | % | [WDI FP.CPI.TOTL.ZG](https://data.worldbank.org/indicator/FP.CPI.TOTL.ZG) |
| 失业率 | 4.6% | % | [WDI SL.UEM.TOTL.ZS](https://data.worldbank.org/indicator/SL.UEM.TOTL.ZS) |
| 商品与服务出口占 GDP | 20.4% | % | [WDI NE.EXP.GNFS.ZS](https://data.worldbank.org/indicator/NE.EXP.GNFS.ZS) |
| 商品与服务进口占 GDP | 17.5% | % | [WDI NE.IMP.GNFS.ZS](https://data.worldbank.org/indicator/NE.IMP.GNFS.ZS) |
| 外商直接投资净流入占 GDP | 0.2% | % | [WDI BX.KLT.DINV.WD.GD.ZS](https://data.worldbank.org/indicator/BX.KLT.DINV.WD.GD.ZS) |
| 制造业增加值占 GDP | 24.8% | % | [WDI NV.IND.MANF.ZS](https://data.worldbank.org/indicator/NV.IND.MANF.ZS) |
| 人口 | 14.09 亿人 | 人 | [WDI SP.POP.TOTL](https://data.worldbank.org/indicator/SP.POP.TOTL) |
| 经常账户余额占 GDP | 2.5% | % | [WDI BN.CAB.XOKA.GD.ZS](https://data.worldbank.org/indicator/BN.CAB.XOKA.GD.ZS) |
| 资本形成总额占 GDP | 40.5% | % | [WDI NE.GDI.TOTL.ZS](https://data.worldbank.org/indicator/NE.GDI.TOTL.ZS) |
| 实际利率 | 5.2% | % | [WDI FR.INR.RINR](https://data.worldbank.org/indicator/FR.INR.RINR) |
| 中央政府债务占 GDP | 暂无数据 | % | [WDI GC.DOD.TOTL.GD.ZS](https://data.worldbank.org/indicator/GC.DOD.TOTL.GD.ZS) |

## 同组参照

GDP 实际增长率（2024 年，同收入组：中高收入）：59/59 个经济体有观测值。
本国数值 5.0%；同组中位数 3.5%；从高到低第 12/59 位，中秩百分位 80.5。
口径提醒：可比较增长方向；各国修订和统计口径仍可能不同。 百分位仅描述数值位置，不是经济质量或投资评分。

## 增长与通胀状态

增长低于历史中位 · 通胀低于历史中位。2024 年实际增长率 4.96%（2014—2023 年中位数 6.77%），消费者价格涨幅 0.22%（同期中位数 1.95%）。

## 双边贸易结构

CEPII BACI 调和双边贸易含 208 个出口伙伴；前五伙伴占比 33.5%，伙伴集中度 HHI 0.039。
贸易快照下载时间（UTC）：2026-09-26T21:23:27.788688+00:00。BACI HS17 V202601，原始数据为 HS6 商品级；此处按伙伴聚合，进口是相同双边流的反向视角。

## IMF 中期预测附录（独立数据版次）

来源：[IMF WEO DataMapper](https://data.imf.org/Datasets/WEO)，April 2026。以下是该版次的 IMF 工作人员预测，不属于上文 WDI 所选年份的历史发布值。

| 指标 | 2026 年预测 | 2027 年预测 | 2031 年预测 |
| --- | ---: | ---: | ---: |
| 实际 GDP 增长率（%） | 4.40 | 4.00 | 3.30 |
| 平均消费者价格涨幅（%） | 1.20 | 1.50 | 2.00 |
| 广义政府总债务占 GDP（%） | 106.90 | 112.50 | 126.80 |
2026 年 7 月 WEO Update 仅为部分指标与经济体更新，未混入本 4 月完整数据库快照。预测随版次变化，不能解释为资产收益。

## 来源、方法与限制

- 年度指标：[世界银行 WDI](https://data.worldbank.org/)；本报告使用 2024 年原值。历史数据可能修订，各指标发布时间不同。
- 贸易数据：[CEPII BACI](https://www.cepii.fr/CEPII/en/bdd_modele/bdd_modele_item.asp?id=37)；仅在国家和年份均有已导入记录时计算。
- 增长与通胀状态仅与本国前十年有效观测的中位数比较，不预测资产回报。
- 跨国同组位置不控制经济规模、汇率、人口结构或统计定义差异；不构成投资建议。
- WDI 快照 SHA-256：`72493e497fc6803f9117ebed1163f076fbf9cac7c2a709f7009291b2517a6f1d`。
- 贸易快照 SHA-256：`43db16b3a8d181f8464416101257ff511226356e7e2e254fb1044779b3339ef4`。
- IMF 预测快照 SHA-256：`d223fc73cca80ca0d0dcd651fa2a7a8f00b60008cf74a4679e5faea01076099e`。
